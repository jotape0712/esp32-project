from flask import Blueprint, request, render_template, redirect, url_for
import json
import os

sensors = Blueprint("sensors", __name__, template_folder="templates")

DATA_FILE = "data_sensors.json"

def carregar_sensores():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {}

def salvar_sensores():
    with open(DATA_FILE, "w") as f:
        json.dump(sensores_dict, f)

# Carrega sensores do arquivo ou inicia vazio
sensores_dict = carregar_sensores()

# Página de cadastro
@sensors.route('/register_sensor')
def register_sensor():
    return render_template("register_sensor.html")

# Adiciona sensor
@sensors.route('/add_sensor', methods=['GET', 'POST'])
def add_sensor():
    global sensores_dict
    if request.method == 'POST':
        sensor = request.form['sensor']
        value = request.form['value']
    else:
        sensor = request.args.get('sensor', None)
        value = request.args.get('value', None)

    sensores_dict[sensor] = value
    salvar_sensores()
    return redirect(url_for('sensors.listar_sensores'))

# Página de listagem
@sensors.route('/sensor')
def listar_sensores():
    return render_template("sensor.html", sensores=sensores_dict)

# Página de remoção
@sensors.route('/remove_sensor')
def remove_sensor():
    return render_template("remove_sensors.html", sensores=sensores_dict)

# Remover sensor
@sensors.route('/del_sensor', methods=['GET', 'POST'])
def del_sensor():
    global sensores_dict
    if request.method == 'POST':
        sensor = request.form['sensor']
    else:
        sensor = request.args.get('sensor', None)

    if sensor in sensores_dict:
        del sensores_dict[sensor]
        salvar_sensores()
    return redirect(url_for('sensors.remove_sensor'))
