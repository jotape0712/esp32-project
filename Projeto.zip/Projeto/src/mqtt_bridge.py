import threading
import json
import paho.mqtt.client as mqtt

# === Variáveis globais para armazenar dados dos sensores ===
dados_climaticos = {
    "temp": 0.0,
    "umidade": 0.0,
    "movimento": 0
}

# Instância do cliente MQTT
mqtt_client = mqtt.Client()

# Callback chamado quando conecta ao broker MQTT
def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("[MQTT] Conectado com sucesso!")
        # Inscreve nos tópicos que receberão dados
        client.subscribe("joaopedro/sensor/dht")
        client.subscribe("joaopedro/sensor/pir")
    else:
        print(f"[MQTT] Falha na conexão, código: {rc}")

# Callback chamado quando uma mensagem MQTT é recebida
def on_message(client, userdata, msg):
    try:
        if msg.topic == "joaopedro/sensor/dht":
            payload = json.loads(msg.payload.decode("utf-8"))
            dados_climaticos["temp"] = float(payload.get("temp", 0))
            dados_climaticos["umidade"] = float(payload.get("hum", 0))

        elif msg.topic == "joaopedro/sensor/pir":
            dados_climaticos["movimento"] = int(msg.payload.decode())

        print(f"[MQTT] Dados atualizados: {dados_climaticos}")

    except Exception as e:
        print("[MQTT] Erro ao processar dados:", e)

# Função para iniciar o cliente MQTT e iniciar loop em thread separada
def iniciar_mqtt():
    mqtt_client.on_connect = on_connect
    mqtt_client.on_message = on_message
    try:
        mqtt_client.connect("broker.hivemq.com", 1883, 60)
        mqtt_client.loop_start()  # Inicia loop em background
    except Exception as e:
        print("[MQTT] Erro ao conectar ao broker:", e)

# Função para iniciar o MQTT em uma thread daemon
def iniciar_em_thread():
    thread = threading.Thread(target=iniciar_mqtt)
    thread.daemon = True
    thread.start()

# Função para ativar buzzer via MQTT
def ativar_buzzer_web():
    payload = {"freq": 500, "volume": 500}
    mqtt_client.publish("joaopedro/atuador/buzzer", json.dumps(payload))

# Função para ativar/desativar relé via MQTT
def ativar_rele_web(estado: bool):
    mqtt_client.publish("joaopedro/atuador/rele", "1" if estado else "0")


# --- Se quiser testar rodando diretamente ---
if __name__ == "__main__":
    iniciar_em_thread()

    # Apenas um loop simples para mostrar dados recebidos
    import time
    while True:
        print(f"Temperatura: {dados_climaticos['temp']} °C")
        print(f"Umidade: {dados_climaticos['umidade']} %")
        print(f"Movimento: {'Sim' if dados_climaticos['movimento'] else 'Não'}")
        time.sleep(5)
