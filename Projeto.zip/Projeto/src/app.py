from flask import Flask, render_template, jsonify, request
from login import login
from sensors import sensors
from actuators import actuators
import mqtt_bridge

app = Flask(__name__)

app.register_blueprint(login, url_prefix='/')
app.register_blueprint(sensors, url_prefix='/')
app.register_blueprint(actuators, url_prefix='/')

@app.route('/')
def index():
    return render_template("login.html")

@app.route('/home')
def home():
    return render_template("home.html")

@app.route('/sensors')
def list_sensors():
    global sensores
    return render_template("sensor.html", devices=sensores)

@app.route('/actuators')
def list_actuators():
    global atuadores
    return render_template("atuadores.html", devices=atuadores)

@app.route('/tempo_real')
def tempo_real():
    return render_template("tempo_real.html")

@app.route('/comando_remoto')
def comando_remoto():
    return render_template("comando_remoto.html")

@app.route('/movimentos')
def movimentos():
    return render_template("movimentos.html", movimento=mqtt_bridge.dados_climaticos["movimento"])

@app.route('/get_dados_movimento')
def get_dados_movimento():
    return jsonify({"movimento": mqtt_bridge.dados_climaticos["movimento"]})


@app.route('/get_dados_clima')
def get_dados_clima():
    return jsonify(mqtt_bridge.dados_climaticos)

@app.route('/ativar_buzzer', methods=['POST'])
def ativar_buzzer():
    try:
        mqtt_bridge.ativar_buzzer_web()
        return jsonify({"status": "Buzzer ativado com sucesso"})
    except Exception as e:
        return jsonify({"status": f"Erro ao ativar buzzer: {str(e)}"}), 500

@app.route('/ativar_rele', methods=['POST'])
def ativar_rele():
    try:
        estado = request.json.get("estado", True)
        mqtt_bridge.ativar_rele_web(estado)
        return jsonify({"status": f"Relé {'ativado' if estado else 'desativado'} com sucesso"})
    except Exception as e:
        return jsonify({"status": f"Erro ao ativar relê: {str(e)}"}), 500

@app.errorhandler(404)
def erro_404(error):
    return render_template('404.html'), 404

@app.errorhandler(405)
def erro_405(error):
    return render_template('405.html'), 405

@app.errorhandler(401)
def erro_401(error):
    return render_template('401.html'), 401

@app.errorhandler(408)
def erro_408(error):
    return render_template('408.html'), 408

@app.errorhandler(429)
def erro_429(error):
    return render_template('429.html'), 429

@app.errorhandler(500)
def erro_500(error):
    return render_template('500.html'), 500

@app.errorhandler(503)
def erro_503(error):
    return render_template('503.html'), 503

if __name__ == '__main__':
    mqtt_bridge.iniciar_em_thread()
    app.run(host='0.0.0.0', port=8080, debug=True)
