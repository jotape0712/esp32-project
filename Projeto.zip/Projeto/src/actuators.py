from flask import Blueprint, request, render_template, redirect, url_for
import json
import os

# Criação do blueprint
actuators = Blueprint("actuators", __name__, template_folder="templates")

# Caminho do arquivo de dados
DATA_FILE = "data_actuators.json"

# Função para carregar atuadores
def carregar_atuadores():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {}

# Função para salvar atuadores
def salvar_atuadores():
    with open(DATA_FILE, "w") as f:
        json.dump(atuadores_dict, f)

# Dicionário de atuadores carregado do JSON
atuadores_dict = carregar_atuadores()

# Página de cadastro de atuador
@actuators.route('/register_actuator')
def register_actuator():
    return render_template("register_actuator.html")

# Adicionar atuador
@actuators.route('/add_actuator', methods=['GET', 'POST'])
def add_actuator():
    global atuadores_dict
    if request.method == 'POST':
        actuator = request.form['actuator']
        value = request.form['value']
    else:
        actuator = request.args.get('actuator', None)
        value = request.args.get('value', None)

    atuadores_dict[actuator] = value
    salvar_atuadores()
    return redirect(url_for('actuators.listar_atuadores'))

# Página de listagem
@actuators.route('/actuators')
def listar_atuadores():
    return render_template("atuadores.html", atuadores=atuadores_dict)

# Página de remoção
@actuators.route('/remove_actuator')
def remove_actuator():
    return render_template("remove_actuator.html", atuadores=atuadores_dict)

# Remover atuador
@actuators.route('/del_actuator', methods=['GET', 'POST'])
def del_actuator():
    global atuadores_dict
    if request.method == 'POST':
        actuator = request.form['actuator']
    else:
        actuator = request.args.get('actuator', None)

    if actuator in atuadores_dict:
        del atuadores_dict[actuator]
        salvar_atuadores()
    return redirect(url_for('actuators.remove_actuator'))
