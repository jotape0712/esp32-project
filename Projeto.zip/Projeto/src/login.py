from flask import Blueprint, request, render_template, redirect, url_for
import json
import os

# Cria o blueprint
login = Blueprint("login", __name__, template_folder="templates")

# Caminho do arquivo JSON dos usuários
DATA_FILE = "data_users.json"

# Função para carregar usuários
def carregar_usuarios():
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    return {}

# Função para salvar usuários
def salvar_usuarios():
    with open(DATA_FILE, "w") as f:
        json.dump(users_dict, f)

# Carrega os usuários existentes
users_dict = carregar_usuarios()

# 🔑 Login
@login.route('/validated_user', methods=['POST'])
def validated_user():
    if request.method == 'POST':
        user = request.form['user']
        password = request.form['password']
        print(user, password)

        if user in users_dict and users_dict[user] == password:
            return render_template('home.html')
        else:
            return '<h1>Credenciais inválidas!</h1>'
    else:
        return render_template('login.html')

# 📋 Listar usuários
@login.route('/list_users')
def list_users():
    return render_template("users.html", users=users_dict)

# ➕ Adicionar usuário
@login.route('/add_user', methods=['GET', 'POST'])
def add_user():
    global users_dict
    if request.method == 'POST':
        user = request.form['user']
        password = request.form['password']
    else:
        user = request.args.get('user', None)
        password = request.args.get('password', None)

    users_dict[user] = password
    salvar_usuarios()
    return redirect(url_for('login.list_users'))

# ❌ Página de remoção
@login.route('/remove_user')
def remove_user():
    return render_template("remove_users.html", users=users_dict)

# 🗑️ Remover usuário
@login.route('/del_user', methods=['GET', 'POST'])
def del_user():
    global users_dict
    if request.method == 'POST':
        user = request.form['user']
    else:
        user = request.args.get('user', None)

    if user in users_dict:
        del users_dict[user]
        salvar_usuarios()

    return redirect(url_for('login.list_users'))

# 📝 Página de registro
@login.route('/register_user')
def register_user():
    return render_template("register_user.html")
